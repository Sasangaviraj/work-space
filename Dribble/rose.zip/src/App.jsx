import React from 'react'
import MainRoute from './routes/main-route'

const App = () => {
  return (
    <MainRoute />
  )
}

export default App