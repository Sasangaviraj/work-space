import React from 'react'
import { Route } from 'react-router';
import { BrowserRouter, Routes } from 'react-router'
import Home from '../pages/home';
import About from '../pages/about';



const MainRoute = () => {
  return(
   <BrowserRouter>
    <Routes>
        <Route path='/' Component={Home} />
        <Route path='about' Component={About} />
       
    </Routes>
  </BrowserRouter>
  );
}

export default  MainRoute