import React from 'react'
import { FaFacebookF, FaInstagram, FaPinterestP, FaTwitter } from 'react-icons/fa'
import { MdCopyright } from 'react-icons/md'

const Footer = () => {
  return (
    <footer className='w-full px-40 pt-15 pb-7 sticky bg-white '>
        {/* footer section line one */}
        <div className="items-center justify-between lg:flex ">
            <div className="">
                 <img
                    src="https://cdn.gymshark.com/images/branding/gs-icon-text.svg"
                    className=" h-5 object-contain"
                />
            </div>

            <div className="flex  flex-wrap gap-x-6 gap-y-2  justify-center max-w-sm mx-auto text-center   lg:gap-14">
                <p className="cursor-pointer text-sm font-semibold ">For designers</p>
                <p className="cursor-pointer text-sm font-semibold ">Hire talent</p>
                <p className="cursor-pointer text-sm font-semibold ">Inspiration</p>
                <p className="cursor-pointer text-sm font-semibold ">Advertising</p>
                <p className="cursor-pointer text-sm font-semibold ">Blog</p>
                <p className="cursor-pointer text-sm font-semibold ">About</p>
                <p className="cursor-pointer text-sm font-semibold ">Careers</p>
                <p className="cursor-pointer text-sm font-semibold ">Support</p>

            </div>

            {/* social icons */}
            <div className="flex gap-2 items-center justify-center">
                <FaTwitter  className='cursor-pointer h-5 w-5'/>
                <FaFacebookF  className='cursor-pointer h-5 w-5'/>
                <FaInstagram  className='cursor-pointer h-5 w-5'/>
                <FaPinterestP  className='cursor-pointer h-5 w-5'/>

            </div>

        </div>

        {/* footer section line two */}
        <div className='mt-20 w-full flex items-center justify-between'>
            <div className='flex items-center justify-center gap-3'>
                <div className="flex gap-1 items-center justify-center">
                    <MdCopyright className='text-gray-400'/>
                    <p className="text-sm text-gray-400 cursor-pointer">2025 Dribbble</p>
                </div>
                <p className='text-sm  text-gray-400 cursor-pointer'>Terms</p>
                <p className='text-sm  text-gray-400 cursor-pointer'>Privacy</p>
                <p className='text-sm  text-gray-400 cursor-pointer'>Cookies</p> 
            </div>
            
            <div className="flex items-center justify-center gap-3 ">
                <p className='text-gray-400 text-sm cursor-pointer'>Jobs</p>
                <p className='text-gray-400 text-sm cursor-pointer'>Designers</p>
                <p className='text-gray-400 text-sm cursor-pointer'>Freelancers</p>
                <p className='text-gray-400 text-sm cursor-pointer'>Tags</p>
                <p className='text-gray-400 text-sm cursor-pointer'>Places</p>
                <p className='text-gray-400 text-sm cursor-pointer'>Resources</p>
            </div>

        </div> 

    </footer>
  )
}

export default Footer