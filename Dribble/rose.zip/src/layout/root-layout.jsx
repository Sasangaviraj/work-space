import React from 'react'
import Header from './header'

const RootLayout = () => {
  return (
    <div className='relative w-full'>
        <Header/>
    </div>
  )
}

export default RootLayout